let a = [1,2,3,4];

console.log("==>",a.filter((e)=>e!=3));